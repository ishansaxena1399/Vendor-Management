import logo from './logo.svg';
import './App.css';
import {BrowserRouter,Route,Routes} from 'react-router-dom';
import VendorListing from './VendorListing';
import VendorCreate from './VendorCreate';
import VendorDetails from './VendorDetails';
import VendorEdit from './VendorEdit';

function App() {
  return (
    <div className="App">
      <h1>React JS CRUD Operation</h1>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<VendorListing/>}></Route>
          <Route path='/vendor/create' element={<VendorCreate/>}></Route>
          <Route path='/vendor/detail/:vendorid' element={<VendorDetails/>}></Route>
          <Route path='/vendor/edit/:vendorid' element={<VendorEdit/>}></Route>

        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
