import { useEffect,useState } from "react";
import { Link, useParams } from "react-router-dom";

const VendorDetails = () => {
    const {vendorid} = useParams();
    const [vendordata,vendordatachange]=useState({});

    useEffect(()=>{
        fetch("http://localhost:8000/vendor/"+vendorid).then((res)=>{
            return res.json();
        }).then((resp)=>{
            vendordatachange(resp);
        }).catch((err)=>{
            console.log(err.message);
        })
    },[]);
    return (
        <div>
            {/* <div className="card" style={{"text-align":"left"}}>
                            <div className="card-title">
                                <h2>Vendor Create</h2>
                            </div>
                            <div className="card-body"></div> */}
            {vendordata &&
            <div>
            <h1>The First Name is :{vendordata.fname}</h1>
            <h1>The Second Name is :{vendordata.lname}</h1>
            <h1>The Date of birth is :{vendordata.dob}</h1>
            <h1>The Email ID is :{vendordata.email}</h1>
            <h1>The Gender is :{vendordata.gender}</h1>
            <h1>The Address is :{vendordata.address}</h1>
            <h1>The Country Name is :{vendordata.country}</h1>
            <h1>The State Name is :{vendordata.state}</h1>
            <h1>The City Name is :{vendordata.city}</h1>
            <h1>The Pincode is :{vendordata.pincode}</h1>
            <h1>The Hobbies are :{vendordata.hobbies}</h1>
            <Link className="btn btn-danger" to="/">Back to Listing</Link>

            </div>
}
        </div>
    );
};

export default VendorDetails;