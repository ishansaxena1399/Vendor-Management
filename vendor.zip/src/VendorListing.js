import { useEffect,useState } from "react";
import { Link, useNavigate } from "react-router-dom";


const VendorListing = () => {
    const[vendordata, vendordatachange]=useState(null);
    const navigate=useNavigate();

    const LoadDetail=(id)=>{
        navigate("/vendor/detail/"+id);
    }

    const LoadEdit=(id)=>{
        navigate("/vendor/edit/"+id);
    }

    const RemoveFunction=(id)=>{
        if(window.confirm('Do you want to remove?')){
            fetch(" http://localhost:8000/vendor/"+id,{
        method:"DELETE"
    }).then((res)=>{
        alert('Removed successfully.')
        window.location.reload();
        navigate('/');

    }).catch((err)=>{
        console.log(err.message)
    })
        }
    }

    const[search,searchChange]=useState("");

    const SearchFunction=()=>{
        const input = document.querySelector('#input');
        fetch(" http://localhost:8000/vendor?q="+input.value).then((res)=>{
            console.log(input.value)
            return res.json();
        }).then((resp)=>{
            vendordatachange(resp);
        }).catch((err)=>{
            console.log(err.message);
        })

    }





    useEffect(()=>{
        fetch("http://localhost:8000/vendor").then((res)=>{
            return res.json();
        }).then((resp)=>{
            vendordatachange(resp);
        }).catch((err)=>{
            console.log(err.message);
        })

    },[])


    // const [value, setValue] = useState('');
    // const [vendordata, setDataSource] = useState(vendordata)
    // const [tableFilter, setTableFilter] = useState([])

    // const filterData = (e)=>{
    //     if(e.targer.value != ""){
    //         setValue(e.target.value);
    //         const filterTable = vendordata.filter(o=>object.keys(o).some(k=>
    //             String(o[k]).toLowercase().include(e.target.value.toLowercase())));
    //             setTableFilter([...filterTable])
    //     } else {
    //         setValue(e.target.value);
    //         setDataSource(...vendordata);
    //     }
    // }
    return (
        <div className="container">
            <div className="card">
                <div className="card-title">
                    <h2>Vendor Listing</h2>

                </div>
                <div className="card-body">
                    <div className="divbtn">
                        <Link to="vendor/create" className="btn btn-success">Add New (+)</Link>
                    </div>
                    <div>
                        <input id="input" value={search} placeholder="Search" onChange={e=>searchChange(e.target.value)}></input>
                        <button onClick={() => SearchFunction()}>Search</button>
                    </div>
                    <table className="table table-bordered">
                        <thead className="bg-dark text-white">
                            <tr>
                                <td>ID</td>
                                <td>First Name</td>
                                <td>Last Name</td>
                                <td>DOB</td>
                                <td>Email</td>
                                <td>Gender</td>
                                <td>Address</td>
                                <td>Country</td>
                                <td>State</td>
                                <td>City</td>
                                <td>Pin Code</td>
                                <td>Hobbies</td>
                                <td>Action</td>
                            </tr>
                        </thead>
                        <tbody>
                            {vendordata &&
                                vendordata.map(item=>(
                                    <tr key={item.id}>
                                        <td>{item.id}</td>
                                        <td>{item.fname}</td>
                                        <td>{item.lname}</td>
                                        <td>{item.email}</td>
                                        <td>{item.dob}</td>
                                        <td>{item.gender}</td>
                                        <td>{item.address}</td>
                                        <td>{item.country}</td>
                                        <td>{item.state}</td>
                                        <td>{item.city}</td>
                                        <td>{item.pincode}</td>
                                        <td>{item.hobbies}</td>
                                        <td><a onClick={()=>{LoadEdit(item.id)}} className="btn btn-success">Edit</a>
                                        <a onClick={()=>{RemoveFunction(item.id)}} className="btn btn-danger">Remove</a>
                                        <a onClick={()=>{LoadDetail(item.id)}} className="btn btn-primary">Details</a>
                                        </td>

                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        
        </div>
    );
};

export default VendorListing;