import { Link,useNavigate } from "react-router-dom";
import { useEffect,useState } from "react";
import Select from 'react-select';

const VendorCreate = () => {

    // const [selectedCountry, setSelectedCountry] = React.useState();
    // const [selectedState, setSelectedState] = React.useState();
    // const [selectedCity, setSelectedCity] = React.useState();
//
    const data = {
        countries: [
          {
            name: "Germany",
            states: [
              {
                name: "A",
                cities: ["Duesseldorf", "Leinfelden-Echterdingen", "Eschborn"]
              }
            ]
          },
          { name: "Spain", states: [{ name: "B", cities: ["Barcelona"] }] },
      
          { name: "USA", states: [{ name: "C", cities: ["Downers Grove"] }] },
          {
            name: "Mexico",
            states: [{ name: ["D", "F", "H"], cities: ["Puebla"] }]
          },
          {
            name: "India",
            states: [
              { name: "E", cities: ["Delhi", "Kolkata", "Mumbai", "Bangalore"] }
            ]
          }
        ]
      };
//

const hobdata = [
  {
    value: 1,
    label: "Nail Paint "
  },
  {
    value: 2,
    label: "Badminton "
  },
  {
    value: 3,
    label: "Cricket "
  },
  {
    value: 4,
    label: "Gaming "
  },
  {
    value: 5,
    label: "Nalla pn "
  },
  {
    value: 6,
    label: "NA "
  }
];

    const[id,idchange]=useState("");
    const[fname,fnamechange]=useState("");
    const[lname,lnamechange]=useState("");
    const[dob,dobchange]=useState("");
    const[email,emailchange]=useState("");
    const[gender,genderchange]=useState("");
    const[address,addresschange]=useState("");
    const[country,countrychange]=useState("");
    const[state,statechange]=useState("");
    const[city,citychange]=useState("");
    const[pincode,pincodechange]=useState("");
    const[hobbies,hobbieschange]=useState("");
    
//
    const availableState = data.countries.find((c) => c.name === country);
    const availableCities = availableState?.states?.find(
      (s) => s.name === state
    );
//
    const navigate=useNavigate();
    //
    const handleChange = (e) => {
      hobbieschange(Array.isArray(e) ? e.map(x => x.label) : []);
    }
//
    const handlesubmit=(e)=>{
    e.preventDefault();
    const vendata = {fname,lname,dob,email,gender,address,country,state,city,pincode,hobbies};
    console.log(vendata)

    fetch(" http://localhost:8000/vendor",{
        method:"POST",
        headers:{"content-type":"application/json"},
        body:JSON.stringify(vendata)
    }).then((res)=>{
        alert('Saved successfully.')
        navigate('/');

    }).catch((err)=>{
        console.log(err.message)
    })
   }

    return (
        <div>
            <div className="row">
                <div className="offset-lg-3 col-lg-6">
                    <form className="container" onSubmit={handlesubmit}>
                        <div className="card" style={{"text-align":"left"}}>
                            <div className="card-title">
                                <h2>Vendor Create</h2>
                            </div>
                            <div className="card-body">
                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>ID</label>
                                            <input value={id} disabled="disabled" className="form-control"></input>
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>First Name</label>
                                            <input value={fname} onChange={e=>fnamechange(e.target.value)} className="form-control"></input>
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>Last Name</label>
                                            <input value={lname} onChange={e=>lnamechange(e.target.value)} className="form-control"></input>
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>DOB</label>
                                            <input value = {dob} type="date" onChange={e=>dobchange(e.target.value)} className="form-control"></input>
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>E-mail</label>
                                            <input value = {email} type="email" onChange={e=>emailchange(e.target.value)} className="form-control"></input>
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>Gender</label>
                                            <div>
                                            <input  name="gender" value = "Male" type="radio" onChange={e=>genderchange(e.target.value)}></input>
                                            <label className="RadioModify">Male</label>
                                            <input  name="gender" value = "Female" type="radio" onChange={e=>genderchange(e.target.value)}></input> 
                                            <label className="RadioModify">Female</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>Address</label>
                                            <input value={address} onChange={e=>addresschange(e.target.value)} className="form-control"></input>
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>Country</label>
                                            <select
                                              placeholder="Country"
                                              value={country}
                                              onChange={(e) => countrychange(e.target.value)}
                                              className="drop"
                                            >
                                              <option>--Choose Country--</option>
                                              {data.countries.map((value, key) => {
                                                return (
                                                  <option value={value.name} key={key}>
                                                    {value.name}
                                                  </option>
                                                );
                                              })}
                                            </select>
                                            {/* <input value={country} onChange={e=>countrychange(e.target.value)} className="form-control"></input> */}
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>State</label>
                                            <select
                                              placeholder="State"
                                              value={state}
                                              onChange={(e) => statechange(e.target.value)}
                                              className="drop"
                                            >
                                              <option>--Choose State--</option>
                                              {availableState?.states.map((e, key) => {
                                                return (
                                                  <option value={e.name} key={key}>
                                                    {e.name}
                                                  </option>
                                                );
                                              })}
                                            </select>
                                            {/* <input value={state} onChange={e=>statechange(e.target.value)} className="form-control"></input> */}
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>City</label>
                                            <select
                                              placeholder="City"
                                              value={city}
                                              onChange={(e) => citychange(e.target.value)}
                                              className="drop"
                                            >
                                              <option>--Choose City--</option>
                                              {availableCities?.cities.map((e, key) => {
                                                return (
                                                  <option value={e.name} key={key}>
                                                    {e}
                                                  </option>
                                                );
                                              })}
                                            </select>
                                            {/* <input value={city} onChange={e=>citychange(e.target.value)} className="form-control"></input> */}
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>Pin Code</label>
                                            <input value={pincode} onChange={e=>pincodechange(e.target.value)} className="form-control"></input>
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>Hobbies</label>
                                            <Select
                                              className="dropdown"
                                              placeholder="Select Option"
                                              value={hobdata.filter(obj => hobbies.includes(obj.label))} // set selected values
                                              options={hobdata} // set list of the data
                                              onChange={handleChange} // assign onChange function
                                              isMulti
                                              isClearable
                                            />
                                            {/* <Multiselect isObject={false} options={opt} value={hobbies} onSelect={e=>hobbieschange(e.target.value) } showCheckbox></Multiselect> */}
                                            {/* <input value={hobbies} onChange={e=>hobbieschange(e.target.value)} className="form-control"></input> */}
                                        </div>
                                    </div>
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <button className="btn btn-success" type="submit">Save</button>
                                            <Link to="/" className="btn btn-danger">Back</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        
        </div>
    );
};

export default VendorCreate;